class PropertyDemo4 {
    var anotherProperty: Int = 314
        private set
}

var p4 = PropertyDemo4()
println(p4.anotherProperty)