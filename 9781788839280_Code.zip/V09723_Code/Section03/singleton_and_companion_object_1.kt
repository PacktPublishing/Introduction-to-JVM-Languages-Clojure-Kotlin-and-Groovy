object ThisIsASingleton {
    fun coolMethod() = println("Not so cool, after all")
}

ThisIsASingleton.coolMethod()