class PropertyDemo2 {
    val readOnlyProperty: Int = 1000
}

val p2 = PropertyDemo2()
println(p2.readOnlyProperty)