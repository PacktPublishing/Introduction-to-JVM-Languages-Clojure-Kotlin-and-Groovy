var currentTime: java.util.Date? = null
var seconds = currentTime?.getTime() ?: -1
println(seconds)