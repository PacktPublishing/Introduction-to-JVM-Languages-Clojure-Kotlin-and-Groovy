// This code does not produce output when loaded inside Kotlin's REPL.
// It must be compiled as described in the chapter.

class MainDemo {
    companion object {
        @JvmStatic fun main(args: Array<String>) {
            println("This is the main method")
        }
    }
}