var favoriteBar = "FooBar"
println("Your favorite bar's name $favoriteBar consists of ${favoriteBar.length} characters")